// How do we know we need a loop here?
//making task that needs to be repeated multiple times over a set of data.

//what's the starting point of the loop?
//define the initial value for the loop variabl which depend on the context
// What's incrementing for each iteration of the loop?
//identify what is changing or progressing in each iteration
// what variables do we need?
// define the necessary variables for the loop

function candyDispenser(mile) {
    for (var distance = 2; distance <= 6; distance += 2) {
      console.log(distance);
    }
  }
  (candyDispenser(mile));