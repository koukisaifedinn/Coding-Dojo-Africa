function greet(name) {
    console.log(`Good day, ${name}!`);
}
var personName = "Anakin"; 
greet(personName);