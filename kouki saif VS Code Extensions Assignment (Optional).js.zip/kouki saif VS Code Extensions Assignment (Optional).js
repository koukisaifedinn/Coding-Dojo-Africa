console.log("I got a rainbow!")
            console.log("I got a rainbow!")