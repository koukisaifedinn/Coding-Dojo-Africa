function greeting(){
    console.log("Hello World")
}
var word = greeting()
console.log()