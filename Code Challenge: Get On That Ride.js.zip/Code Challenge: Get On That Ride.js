var heigh=42
var age=10
if(heigh>=42){
    console.log("Get on that ride, kiddo!") 
}
else{
    console.log("sorry kiddo. Maybe next year.") 
}
if(age>=10){
    console.log("Get on that ride, kiddo!")
}
else{
    console.log("sorry kiddo. Maybe next year.")
}