var minimumAge=10
var minimumHeight=42